const dns = require('dns');

module.exports = {
    name: 'NS Record Query',
    description: 'Queries nameserver records',
    
    execute: async (target, port) => {
        return new Promise((resolve, reject) => {
            dns.resolveNs(target, (err, records) => {
                if (err) reject(err);
                else resolve({ records, queryType: 'NS' });
            });
        });
    },
    
    flood: (target, port, callback) => {
        dns.resolveNs(target, (err) => {
            callback(!err);
        });
    }
};