const dns = require('dns');

module.exports = {
    name: 'Same Domain Flood',
    description: 'Repeated queries to same domain',
    
    execute: async (target, port) => {
        return new Promise((resolve, reject) => {
            dns.resolve4(target, (err, addresses) => {
                if (err) reject(err);
                else resolve({ addresses });
            });
        });
    },
    
    flood: (target, port, callback) => {
        dns.resolve4(target, (err) => {
            callback(!err);
        });
    }
};