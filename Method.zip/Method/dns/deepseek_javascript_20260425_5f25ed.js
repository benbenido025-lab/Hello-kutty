const dns = require('dns');

module.exports = {
    name: 'PTR Record Query',
    description: 'Reverse DNS lookup',
    
    execute: async (target, port) => {
        return new Promise((resolve, reject) => {
            dns.reverse(target, (err, hostnames) => {
                if (err) reject(err);
                else resolve({ hostnames, queryType: 'PTR' });
            });
        });
    },
    
    flood: (target, port, callback) => {
        dns.reverse(target, (err) => {
            callback(!err);
        });
    }
};