const dns = require('dns');

module.exports = {
    name: 'NAPTR Record Query',
    description: 'Queries naming authority pointer records',
    
    execute: async (target, port) => {
        return new Promise((resolve, reject) => {
            dns.resolveNaptr(target, (err, records) => {
                if (err) reject(err);
                else resolve({ records });
            });
        });
    },
    
    flood: (target, port, callback) => {
        dns.resolveNaptr(target, (err) => {
            callback(!err);
        });
    }
};