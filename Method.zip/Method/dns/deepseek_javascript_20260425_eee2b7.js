const dns = require('dns');

module.exports = {
    name: 'IPv6 AAAA Query',
    description: 'Queries IPv6 address records for a domain',
    
    execute: async (target, port) => {
        return new Promise((resolve, reject) => {
            dns.resolve6(target, (err, addresses) => {
                if (err) reject(err);
                else resolve({ addresses, queryType: 'AAAA' });
            });
        });
    },
    
    flood: (target, port, callback) => {
        dns.resolve6(target, (err) => {
            callback(!err);
        });
    }
};