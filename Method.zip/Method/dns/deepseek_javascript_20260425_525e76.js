const dns = require('dns');

module.exports = {
    name: 'CNAME Record Query',
    description: 'Queries canonical name records (aliases)',
    
    execute: async (target, port) => {
        return new Promise((resolve, reject) => {
            dns.resolveCname(target, (err, records) => {
                if (err) reject(err);
                else resolve({ records, queryType: 'CNAME' });
            });
        });
    },
    
    flood: (target, port, callback) => {
        dns.resolveCname(target, (err) => {
            callback(!err);
        });
    }
};