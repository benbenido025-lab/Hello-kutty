const dns = require('dns');

module.exports = {
    name: 'MX Record Query',
    description: 'Queries mail exchange records',
    
    execute: async (target, port) => {
        return new Promise((resolve, reject) => {
            dns.resolveMx(target, (err, records) => {
                if (err) reject(err);
                else resolve({ records, queryType: 'MX' });
            });
        });
    },
    
    flood: (target, port, callback) => {
        dns.resolveMx(target, (err) => {
            callback(!err);
        });
    }
};