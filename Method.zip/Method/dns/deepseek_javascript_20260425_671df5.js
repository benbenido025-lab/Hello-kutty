const dns = require('dns');

module.exports = {
    name: 'SOA Record Query',
    description: 'Queries start of authority records',
    
    execute: async (target, port) => {
        return new Promise((resolve, reject) => {
            dns.resolveSoa(target, (err, record) => {
                if (err) reject(err);
                else resolve({ record, queryType: 'SOA' });
            });
        });
    },
    
    flood: (target, port, callback) => {
        dns.resolveSoa(target, (err) => {
            callback(!err);
        });
    }
};