const dns = require('dns');

module.exports = {
    name: 'Mixed Record Types',
    description: 'Queries multiple record types rapidly',
    
    execute: async (target, port) => {
        const types = ['A', 'AAAA', 'MX', 'TXT'];
        const results = {};
        
        for (const type of types) {
            await new Promise((resolve) => {
                if (type === 'A') dns.resolve4(target, (err, res) => { results[type] = err ? null : res; resolve(); });
                else if (type === 'AAAA') dns.resolve6(target, (err, res) => { results[type] = err ? null : res; resolve(); });
                else if (type === 'MX') dns.resolveMx(target, (err, res) => { results[type] = err ? null : res; resolve(); });
                else if (type === 'TXT') dns.resolveTxt(target, (err, res) => { results[type] = err ? null : res; resolve(); });
            });
        }
        
        return { results };
    },
    
    flood: (target, port, callback) => {
        dns.resolve4(target, () => {
            dns.resolve6(target, () => {
                dns.resolveMx(target, () => {
                    dns.resolveTxt(target, () => {
                        callback(true);
                    });
                });
            });
        });
    }
};