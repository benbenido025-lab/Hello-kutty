const dns = require('dns');
const crypto = require('crypto');

module.exports = {
    name: 'SRV Record Flood',
    description: 'Queries service records',
    
    execute: async (target, port) => {
        const srvDomain = `_http._tcp.${target}`;
        return new Promise((resolve, reject) => {
            dns.resolveSrv(srvDomain, (err, records) => {
                if (err) reject(err);
                else resolve({ records });
            });
        });
    },
    
    flood: (target, port, callback) => {
        const srvDomain = `_http._tcp.${target}`;
        dns.resolveSrv(srvDomain, (err) => {
            callback(!err);
        });
    }
};