const dns = require('dns');

module.exports = {
    name: 'TXT Record Query',
    description: 'Queries text records (SPF, DKIM, etc)',
    
    execute: async (target, port) => {
        return new Promise((resolve, reject) => {
            dns.resolveTxt(target, (err, records) => {
                if (err) reject(err);
                else resolve({ records, queryType: 'TXT' });
            });
        });
    },
    
    flood: (target, port, callback) => {
        dns.resolveTxt(target, (err) => {
            callback(!err);
        });
    }
};