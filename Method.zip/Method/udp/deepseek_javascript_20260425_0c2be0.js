const dgram = require('dgram');

module.exports = {
    name: 'UDP Broadcast Flood',
    description: 'Sends broadcast UDP packets',
    
    execute: async (target, port) => {
        const socket = dgram.createSocket('udp4');
        const message = Buffer.from('BROADCAST');
        
        socket.setBroadcast(true);
        
        return new Promise((resolve, reject) => {
            socket.send(message, port, '255.255.255.255', (err) => {
                if (err) reject(err);
                else resolve({ broadcast: true });
                socket.close();
            });
        });
    },
    
    flood: (target, port, callback) => {
        const socket = dgram.createSocket('udp4');
        const message = Buffer.from('BROADCAST');
        
        socket.setBroadcast(true);
        socket.send(message, port, '255.255.255.255', (err) => {
            socket.close();
            callback(!err);
        });
    }
};